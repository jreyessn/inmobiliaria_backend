<?php

namespace App\Repositories\Customer;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CustomerRepository.
 *
 * @package namespace App\Repositories\Customer;
 */
interface CustomerRepository extends RepositoryInterface
{
    //
}
