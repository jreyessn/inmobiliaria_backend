<?php

namespace App\Repositories\Furniture;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface FurnitureRepository.
 *
 * @package namespace App\Repositories\Furniture;
 */
interface FurnitureRepository extends RepositoryInterface
{
    //
}
