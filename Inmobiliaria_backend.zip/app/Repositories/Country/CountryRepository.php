<?php

namespace App\Repositories\Country;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CountryRepository.
 *
 * @package namespace App\Repositories\Country;
 */
interface CountryRepository extends RepositoryInterface
{
    //
}
