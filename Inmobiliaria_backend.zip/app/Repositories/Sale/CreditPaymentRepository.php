<?php

namespace App\Repositories\Sale;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CreditPaymentRepository.
 *
 * @package namespace App\Repositories\Sale;
 */
interface CreditPaymentRepository extends RepositoryInterface
{
    //
}
