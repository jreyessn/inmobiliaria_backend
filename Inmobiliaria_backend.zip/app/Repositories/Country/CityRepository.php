<?php

namespace App\Repositories\Country;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CityRepository.
 *
 * @package namespace App\Repositories\Country;
 */
interface CityRepository extends RepositoryInterface
{
    //
}
