<?php

namespace App\Repositories\Furniture;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UrbanitationRepository.
 *
 * @package namespace App\Repositories\Furniture;
 */
interface UrbanitationRepository extends RepositoryInterface
{
    //
}
