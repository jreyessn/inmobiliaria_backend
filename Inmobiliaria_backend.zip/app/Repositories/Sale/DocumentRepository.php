<?php

namespace App\Repositories\Sale;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface DocumentRepository.
 *
 * @package namespace App\Repositories\Sale;
 */
interface DocumentRepository extends RepositoryInterface
{
    //
}
