<?php

namespace App\Repositories\Sale;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CreditCuoteRepository.
 *
 * @package namespace App\Repositories\Sale;
 */
interface CreditCuoteRepository extends RepositoryInterface
{
    //
}
