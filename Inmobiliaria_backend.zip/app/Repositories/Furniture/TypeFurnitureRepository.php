<?php

namespace App\Repositories\Furniture;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface TypeFurnitureRepository.
 *
 * @package namespace App\Repositories\Furniture;
 */
interface TypeFurnitureRepository extends RepositoryInterface
{
    //
}
