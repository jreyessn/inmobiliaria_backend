<?php

namespace App\Repositories\Sale;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface SaleRepository.
 *
 * @package namespace App\Repositories\Sale;
 */
interface SaleRepository extends RepositoryInterface
{
    //
}
