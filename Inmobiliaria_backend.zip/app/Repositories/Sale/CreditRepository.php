<?php

namespace App\Repositories\Sale;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CreditRepository.
 *
 * @package namespace App\Repositories\Sale;
 */
interface CreditRepository extends RepositoryInterface
{
    //
}
