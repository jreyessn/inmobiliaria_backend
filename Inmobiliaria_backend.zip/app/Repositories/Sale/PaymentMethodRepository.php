<?php

namespace App\Repositories\Sale;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PaymentMethodRepository.
 *
 * @package namespace App\Repositories\Sale;
 */
interface PaymentMethodRepository extends RepositoryInterface
{
    //
}
