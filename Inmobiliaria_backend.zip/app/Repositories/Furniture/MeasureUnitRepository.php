<?php

namespace App\Repositories\Furniture;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface MeasureUnitRepository.
 *
 * @package namespace App\Repositories\Furniture;
 */
interface MeasureUnitRepository extends RepositoryInterface
{
    //
}
