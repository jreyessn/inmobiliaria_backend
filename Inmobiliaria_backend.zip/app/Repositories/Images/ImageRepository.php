<?php

namespace App\Repositories\Images;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ImageRepository.
 *
 * @package namespace App\Repositories\Images;
 */
interface ImageRepository extends RepositoryInterface
{
    //
}
